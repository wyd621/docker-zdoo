<?php if(!defined("RUN_MODE")) die();?>
<?php
$lang->cart->common = '購物車';
$lang->cart->browse = '我的購物車';

$lang->cart->noProducts     = "購物車內沒有商品。";
$lang->cart->pickProducts   = "去挑選商品";
$lang->cart->goAccount      = "去結算";
$lang->cart->goHome         = "返迴首頁";

$lang->cart->topbarInfo     = "<i class='icon icon-shopping-cart text-danger'></i> 購物車<font class='text-danger'>%s</font>";
