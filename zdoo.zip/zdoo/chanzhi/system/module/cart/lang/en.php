<?php if(!defined("RUN_MODE")) die();?>
<?php
$lang->cart->common = 'Shopping Cart';
$lang->cart->browse = 'My Shopping Cart';

$lang->cart->noProducts     = "The cart is empty.";
$lang->cart->pickProducts   = "Go to pick goods.";
$lang->cart->goAccount      = "Go Account";
$lang->cart->goHome         = "Back to home page.";

$lang->cart->topbarInfo     = "<i class='icon icon-shopping-cart text-danger'></i> Cart <font class='text-danger'>%s</font>";
