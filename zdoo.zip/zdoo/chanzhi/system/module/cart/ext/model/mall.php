<?php
/**
 * Add a prodcut to cart. 
 * 
 * @param  int    $productID 
 * @param  int    $count 
 * @access public
 * @return void
 */
public function add($productID, $count)
{
    $product = new stdclass();
    $product->product = $productID;
    $product->account = $this->app->user->account;
    $product->count   = $count;
    $product->extra   = helper::jsonEncode($this->post->extra);

    $this->dao->insert(TABLE_CART)->data($product)->exec();

    return !dao::isError();
}

/**
 * Get product list in cart of an account.
 * 
 * @param  string $account 
 * @access public
 * @return void
 */
public function getListByAccount($account = '')
{
    if($this->app->user->account != 'guest')
    {
        $goodsList = $this->dao->select('*')->from(TABLE_CART)->where('account')->eq($account)->fetchAll('id');
    }
    else
    {
        $goodsInDb     = $this->dao->select('*')->from(TABLE_CART)->where('account')->eq($account)->fetchAll('id');
        $goodsInCookie = $this->getListByCookie();
        $goodsList     = (array) $goodsInDb + (array) $goodsInCookie;
    }
    if(empty($goodsList)) return null;
    foreach($goodsList as $goods) $productIdList[] = $goods->product;

    /* Get products(use groupBy to distinct products).  */
    $products = $this->dao->select('t1.*, t2.category')->from(TABLE_PRODUCT)->alias('t1')
        ->leftJoin(TABLE_RELATION)->alias('t2')->on('t1.id = t2.id')
        ->where('t1.id')->in($productIdList)
        ->andWhere('t2.type')->eq('product')
        ->beginIF(RUN_MODE == 'front')->andWhere('t1.status')->eq('normal')->fi()
        ->groupBy('t2.id')
        ->fetchAll('id');

    if(empty($products)) return array();

    /* Get categories for these products. */
    $categories = $this->dao->select('t2.id, t2.name, t2.alias, t1.id AS product')
        ->from(TABLE_RELATION)->alias('t1')
        ->leftJoin(TABLE_CATEGORY)->alias('t2')->on('t1.category = t2.id')
        ->where('t2.type')->eq('product')
        ->andWhere('t1.id')->in(array_keys($products))
        ->fetchGroup('product', 'id');

    /* Assign categories to it's product. */
    foreach($products as $product) $product->categories = !empty($categories[$product->id]) ? $categories[$product->id] : array();

    /* Get images for these products. */
    $images = $this->loadModel('file')->getByObject('product', array_keys($products), $isImage = true);

    $this->loadModel('product');
    /* Assign images to it's product. */
    foreach($goodsList as $goods)
    {
        $product = zget($products, $goods->product, '');
        if(empty($product)) continue;
        $goods->name       = $product->name;
        $goods->alias      = $product->alias;
        $goods->category   = $product->category;
        $goods->categories = $product->categories;

        $priceSetting = $this->product->getPrices($product->id);
        $basicPrice   = $product->promotion > 0 ? $product->promotion : $product->price;
        if(!is_object($goods->extra)) $goods->extra = json_decode($goods->extra);

        if(!empty($goods->extra))
        {
            foreach($goods->extra as $attribute => $value)
            {
                $label = helper::safe64Encode($value);
                $setting = zget($priceSetting, $attribute, array());
                $price   = zget($setting, $label, array());
                $basicPrice += zget($price, 'price');
            }
        }

        $goods->price = $basicPrice;
        $goods->promotion = 0;

        $goods->attributes = $this->loadModel('attribute')->getPairs(array_keys($product->categories));

        if(!empty($images[$product->id]))
        {
            $goods->image = new stdclass();
            if(isset($images[$goods->product]))  $goods->image->list = $images[$goods->product];
            if(!empty($goods->image->list)) $goods->image->primary = $goods->image->list[0];
        }
    }

    return $goodsList;
}

/**
 * Add a prodcut to cart, save in cookie. 
 * 
 * @param  int    $productID 
 * @param  int    $count 
 * @access public
 * @return void
 */
public function addInCookie($productID, $count)
{
    $cart = $this->getListByCookie();
    $goods = new stdclass();
    $goods->product = $productID;
    $goods->count   = $count;
    $goods->extra   = $this->post->extra;

    $id = uniqid('cart');
    $cart->$id = $goods;

    setcookie('cart', json_encode($cart), time() + 60 * 60 * 24);
}

/**
 * Get list from cookie. 
 * 
 * @access public
 * @return array
 */
public function getListByCookie()
{
    $cart = ($this->cookie->cart === false or $this->cookie->cart == '') ? array() : json_decode($this->cookie->cart);
    $cart = (object) $cart;
    foreach($cart as $id => $goods)
    {
        $goods->account = 'guest';
        $goods->lang    = $this->app->getClientlang();
    }

    return $cart;
}

/**
 * Delete a product to cart, save in cookie. 
 * 
 * @param  int    $id 
 * @access public
 * @return void
 */
public function deleteInCookie($id)
{
    $cart = $this->getListByCookie();
    if(isset($cart->$id)) unset($cart->$id);
    setcookie('cart', json_encode($cart), time() + 60 * 60 * 24);
}

/**
 * Merge goods in cookie to db if user is logon. 
 * 
 * @access public
 * @return void
 */
public function mergeToDb()
{
    if($this->app->user->account == 'guest') return true;
    $goodsList = $this->getListByCookie();
    foreach($goodsList as $id => $goods)
    {
        $goods->account = $this->app->user->account;
        $goods->extra   = helper::jsonEncode($goods->extra);
        $this->dao->insert(TABLE_CART)->data($goods)->exec();
        unset($goodsList->$id);
    }
    setcookie('cart', json_encode($goodsList), time() + 60 * 60 * 24);
}
