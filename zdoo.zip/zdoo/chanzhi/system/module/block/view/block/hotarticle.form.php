<?php if(!defined("RUN_MODE")) die();?>
<?php include 'latestarticle.form.php';?>
