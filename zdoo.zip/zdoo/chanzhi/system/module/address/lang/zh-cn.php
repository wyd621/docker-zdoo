<?php if(!defined("RUN_MODE")) die();?>
<?php
$lang->address->common  = '地址';
$lang->address->address = '详细地址';
$lang->address->phone   = '联系电话';
$lang->address->zipcode = '邮政编码';
$lang->address->contact = '联系人';

$lang->address->browse = '地址列表';
$lang->address->create = '添加新地址';
$lang->address->edit   = '编辑地址';
