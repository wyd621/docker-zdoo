<?php if(!defined("RUN_MODE")) die();?>
<?php
$lang->address->common  = '地址';
$lang->address->address = '詳細地址';
$lang->address->phone   = '聯繫電話';
$lang->address->zipcode = '郵政編碼';
$lang->address->contact = '聯繫人';

$lang->address->browse = '地址列表';
$lang->address->create = '添加新地址';
$lang->address->edit   = '編輯地址';
