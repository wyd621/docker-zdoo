ALTER TABLE `eps_user` ADD `security` text after `emailCertified`; 
ALTER TABLE `eps_thread` ADD INDEX `stick` (`stick`);
