ALTER TABLE `eps_file` CHANGE `pathname` `pathname` char(100) NOT NULL;
