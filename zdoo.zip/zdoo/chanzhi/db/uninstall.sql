DROP TABLE IF EXISTS `eps_attribute`;
DROP TABLE IF EXISTS `eps_product_attribute`;
DROP TABLE IF EXISTS `eps_product_price`;

ALTER TABLE `eps_cart` DROP extra;
ALTER TABLE `eps_order_product` DROP extra;
ALTER TABLE `eps_order` DROP track;
