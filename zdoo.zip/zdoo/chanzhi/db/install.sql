DROP TABLE IF EXISTS `eps_attribute`;
CREATE TABLE `eps_attribute` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `category` mediumint(8) NOT NULL DEFAULT 0,
  `code` char(30) NOT NULL,
  `name` varchar(100) NOT NULL,
  `inputType` char(30) NOT NULL,
  `search` char(30) NOT NULL,
  `values` TEXT NOT NULL,
  `default` TEXT NOT NULL,
  `sort` smallint(5) NOT NULL DEFAULT 0,
  `lang` char(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category` (`category`),
  KEY `search` (`category`),
  KEY `lang` (`lang`),
  KEY `code` (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `eps_product_attribute`;
CREATE TABLE `eps_product_attribute` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `product` mediumint(9) NOT NULL,
  `attribute` char(30) NOT NULL,
  `value` varchar(255) NOT NULL,
  `lang` char(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lang` (`lang`),
  KEY `value` (`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `eps_product_price`;
CREATE TABLE `eps_product_price` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `product` mediumint(9) NOT NULL,
  `attribute` char(30) NOT NULL,
  `value` char(30) NOT NULL,
  `price` decimal(10, 2) NOT NULL DEFAULT 0.00,
  `inputType` char(30) NOT NULL,
  `lang` char(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lang` (`lang`),
  KEY `attribute` (`attribute`),
  KEY `value` (`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

ALTER TABLE `eps_cart` ADD extra text NOT NULL;
ALTER TABLE `eps_order_product` ADD extra text NOT NULL;
ALTER TABLE `eps_order` ADD track TEXT NOT NULL AFTER waybill;
ALTER TABLE `eps_order` CHANGE express express char(30) NOT NULL AFTER waybill;
